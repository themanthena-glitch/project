// ===== BOOKING SYSTEM =====
let selectedPro = null;
let selectedDate = null;
let selectedTime = null;

function openBooking(proId) {
  selectedPro = PROFESSIONALS.find(p => p.id === proId);
  if (!selectedPro) return;

  selectedDate = null;
  selectedTime = null;

  document.getElementById('modal-pro-name').textContent = selectedPro.name;
  document.getElementById('modal-pro-role').textContent = selectedPro.role;
  document.getElementById('modal-pro-avatar').textContent = selectedPro.avatar;
  document.getElementById('modal-pro-rating').textContent = `⭐ ${selectedPro.rating} · ${selectedPro.reviews} reviews`;

  // Generate dates (next 6 available days)
  const dateSlots = document.getElementById('date-slots');
  dateSlots.innerHTML = '';
  const days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  for (let i = 1; i <= 6; i++) {
    const d = new Date();
    d.setDate(d.getDate() + i);
    const btn = document.createElement('button');
    btn.className = 'date-slot';
    btn.innerHTML = `<div style="font-size:10px;opacity:0.7">${days[d.getDay()]}</div><div style="font-size:15px;font-weight:700">${d.getDate()}</div><div style="font-size:10px;opacity:0.7">${months[d.getMonth()]}</div>`;
    btn.onclick = () => selectDate(btn, `${days[d.getDay()]}, ${d.getDate()} ${months[d.getMonth()]}`);
    dateSlots.appendChild(btn);
  }

  // Generate time slots
  const timeSlots = document.getElementById('time-slots');
  timeSlots.innerHTML = '';
  const times = ['9:00 AM','10:00 AM','11:00 AM','12:00 PM','2:00 PM','3:00 PM','4:00 PM','5:00 PM'];
  const unavailable = ['11:00 AM', '3:00 PM'];
  times.forEach(t => {
    const btn = document.createElement('button');
    btn.className = 'time-slot' + (unavailable.includes(t) ? ' unavailable' : '');
    btn.textContent = t;
    if (!unavailable.includes(t)) btn.onclick = () => selectTime(btn, t);
    timeSlots.appendChild(btn);
  });

  document.getElementById('booking-form').style.display = 'block';
  document.getElementById('confirm-screen').style.display = 'none';
  document.getElementById('booking-modal').classList.add('open');
}

function selectDate(btn, val) {
  document.querySelectorAll('.date-slot').forEach(b => b.classList.remove('selected'));
  btn.classList.add('selected');
  selectedDate = val;
}

function selectTime(btn, val) {
  document.querySelectorAll('.time-slot:not(.unavailable)').forEach(b => b.classList.remove('selected'));
  btn.classList.add('selected');
  selectedTime = val;
}

function closeBooking() {
  document.getElementById('booking-modal').classList.remove('open');
}

function confirmBooking() {
  const name = document.getElementById('client-name').value.trim();
  const email = document.getElementById('client-email').value.trim();
  const project = document.getElementById('project-type').value;

  if (!name || !email) { alert('Please enter your name and email.'); return; }
  if (!selectedDate) { alert('Please select a date.'); return; }
  if (!selectedTime) { alert('Please select a time slot.'); return; }
  if (!project) { alert('Please select a project type.'); return; }

  // Save booking to localStorage
  const bookings = JSON.parse(localStorage.getItem('fp_bookings') || '[]');
  bookings.unshift({
    id: Date.now(),
    proId: selectedPro.id,
    proName: selectedPro.name,
    proRole: selectedPro.role,
    proAvatar: selectedPro.avatar,
    clientName: name,
    clientEmail: email,
    projectType: project,
    date: selectedDate,
    time: selectedTime,
    status: 'confirmed',
    bookedAt: new Date().toISOString()
  });
  localStorage.setItem('fp_bookings', JSON.stringify(bookings));

  // Show confirmation
  document.getElementById('booking-form').style.display = 'none';
  document.getElementById('confirm-screen').style.display = 'block';
  document.getElementById('confirm-pro-name').textContent = selectedPro.name;
  document.getElementById('confirm-date').textContent = `${selectedDate} at ${selectedTime}`;
}

// Close on backdrop click
document.addEventListener('click', e => {
  if (e.target.id === 'booking-modal') closeBooking();
});
