// ===== SMART AI CHATBOT WITH INLINE PRO CARDS + BOOKING =====

// Chat conversation history for multi-turn context
let chatHistory = [];

// Detect if user is asking for a professional
function detectProfessionalIntent(msg) {
  const m = msg.toLowerCase();
  const intents = [
    { keys: ['designer','design','ux','ui','figma','graphic','brand','logo','visual'], cat: 'designer', label: 'Designer' },
    { keys: ['developer','dev','coder','programmer','react','python','node','full stack','mobile','app','backend','frontend','software'], cat: 'developer', label: 'Developer' },
    { keys: ['photographer','photo','shoot','wedding photo','portrait','product photo'], cat: 'photographer', label: 'Photographer' },
    { keys: ['architect','architecture','building design','house design','interior'], cat: 'architect', label: 'Architect' },
    { keys: ['marketer','marketing','seo','ads','digital marketing','social media','ppc'], cat: 'marketer', label: 'Marketer' },
    { keys: ['writer','copywriter','content','blog','article','copy'], cat: 'writer', label: 'Writer' },
  ];

  // Trigger words that show user wants to FIND someone
  const findTriggers = ['find','need','looking for','want','show','get me','hire','best','top','recommend','suggest','who can','someone who'];
  const hasFindTrigger = findTriggers.some(t => m.includes(t));

  for (const intent of intents) {
    if (intent.keys.some(k => m.includes(k))) {
      return { found: true, category: intent.cat, label: intent.label, hasFindTrigger };
    }
  }
  return { found: false };
}

// Get top 3 from the PROFESSIONALS array
function getTop3(category) {
  if (typeof PROFESSIONALS === 'undefined') return [];
  return [...PROFESSIONALS]
    .filter(p => p.category === category)
    .sort((a, b) => b.aiScore - a.aiScore)
    .slice(0, 3);
}

// Render inline mini pro card inside chat
function renderChatProCard(p, rank) {
  const stars = '★'.repeat(Math.floor(p.rating)) + (p.rating % 1 >= 0.5 ? '½' : '');
  const priceDisplay = `₹${p.rate.toLocaleString()}${p.rateUnit}`;
  return `
    <div class="chat-pro-card" id="chatcard-${p.id}">
      <div class="cpc-rank">#${rank} AI Pick</div>
      <div class="cpc-top">
        <div class="cpc-avatar">${p.avatar}</div>
        <div class="cpc-info">
          <div class="cpc-name">${p.name} ${p.verified ? '<span class="cpc-verified">✓</span>' : ''}</div>
          <div class="cpc-role">${p.role}</div>
          <div class="cpc-meta">
            <span class="cpc-stars">${stars}</span>
            <span class="cpc-rating">${p.rating}</span>
            <span class="cpc-reviews">(${p.reviews})</span>
            <span class="cpc-dot">·</span>
            <span class="cpc-exp">${p.experience}</span>
          </div>
        </div>
      </div>
      <div class="cpc-skills">${p.skills.slice(0,3).map(s=>`<span>${s}</span>`).join('')}</div>
      <div class="cpc-score-row">
        <span class="cpc-score-label">AI Match</span>
        <div class="cpc-score-track"><div class="cpc-score-fill" style="width:${p.aiScore}%"></div></div>
        <span class="cpc-score-val">${p.aiScore}%</span>
      </div>
      <div class="cpc-footer">
        <div class="cpc-price">${priceDisplay}</div>
        <button class="cpc-book-btn" onclick="openChatBooking(${p.id})">
          📅 Book Appointment
        </button>
      </div>
    </div>`;
}

// Render top 3 as a chat bubble with cards
function addTop3Cards(pros, category, intro) {
  const msgs = document.getElementById('chat-messages');
  const wrap = document.createElement('div');
  wrap.className = 'msg bot';
  wrap.innerHTML = `
    <div class="bubble chat-results-bubble">
      <div class="crb-header">
        <span class="crb-icon">🤖</span>
        <span>${intro}</span>
      </div>
      <div class="chat-pro-cards">
        ${pros.map((p, i) => renderChatProCard(p, i + 1)).join('')}
      </div>
      <div class="crb-footer">
        <button class="crb-see-all" onclick="window.location='${window.location.pathname.includes('pages') ? '' : 'pages/'}search.html?q=${category}'">
          See all ${category}s →
        </button>
      </div>
    </div>`;
  msgs.appendChild(wrap);
  msgs.scrollTop = msgs.scrollHeight;
}

// Open booking modal directly from chat card
function openChatBooking(proId) {
  if (typeof openBooking === 'function') {
    openBooking(proId);
  } else {
    // On pages that don't have booking.js loaded (like index.html), redirect
    window.location = `pages/search.html?q=&book=${proId}`;
  }
}

function toggleChat() {
  const widget = document.getElementById('chat-widget');
  const fab = document.getElementById('chat-fab');
  widget.classList.toggle('open');
  if (widget.classList.contains('open')) {
    const badge = fab?.querySelector('.chat-badge');
    if (badge) badge.style.display = 'none';
    document.getElementById('chat-inp').focus();
  }
}

function addMsg(text, role) {
  const msgs = document.getElementById('chat-messages');
  const div = document.createElement('div');
  div.className = `msg ${role}`;
  div.innerHTML = `<div class="bubble">${text.replace(/\n/g,'<br>').replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>').replace(/_(.*?)_/g,'<em>$1</em>')}</div>`;
  msgs.appendChild(div);
  msgs.scrollTop = msgs.scrollHeight;
}

function showTyping() {
  let t = document.getElementById('typing-ind');
  if (!t) {
    t = document.createElement('div');
    t.id = 'typing-ind';
    t.className = 'typing-dots show';
    t.innerHTML = `<div class="bubble"><div class="dot"></div><div class="dot"></div><div class="dot"></div></div>`;
    document.getElementById('chat-messages').appendChild(t);
  }
  t.className = 'typing-dots show';
  document.getElementById('chat-messages').scrollTop = 99999;
}
function hideTyping() {
  const t = document.getElementById('typing-ind');
  if (t) t.remove();
}

async function sendChat() {
  const inp = document.getElementById('chat-inp');
  const msg = inp.value.trim();
  if (!msg) return;
  inp.value = '';

  const sugg = document.getElementById('chat-sugg');
  if (sugg) sugg.style.display = 'none';

  addMsg(msg, 'user');
  chatHistory.push({ role: 'user', content: msg });
  showTyping();

  // Detect if user wants professionals
  const intent = detectProfessionalIntent(msg);

  if (intent.found) {
    const top3 = getTop3(intent.category);

    if (top3.length > 0) {
      try {
        // Get AI intro text for the results
        const proSummary = top3.map((p,i) => `#${i+1}: ${p.name} (${p.role}, ${p.rating}★, ₹${p.rate.toLocaleString()}${p.rateUnit}, AI Score: ${p.aiScore}%)`).join('\n');
        const res = await fetch("https://api.anthropic.com/v1/messages", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            model: "claude-sonnet-4-20250514",
            max_tokens: 1000,
            system: `You are FindPro AI. The user asked for a professional. Write ONE short sentence (max 20 words) introducing the top 3 results below. Be friendly and specific to the category. Don't use markdown.`,
            messages: [{ role: "user", content: `User asked: "${msg}"\n\nTop 3 ${intent.label}s found:\n${proSummary}\n\nWrite a 1-sentence intro for showing these results.` }]
          })
        });
        const data = await res.json();
        hideTyping();
        const intro = data.content?.map(b => b.text||'').join('').trim() || `Here are the top 3 ${intent.label}s I found for you:`;
        addTop3Cards(top3, intent.category, intro);

        const botMsg = `Click **Book Appointment** on any card above to schedule a session. Need a different type of professional?`;
        addMsg(botMsg, 'bot');
        chatHistory.push({ role: 'assistant', content: intro + ' [showed top 3 cards] ' + botMsg });
      } catch(e) {
        hideTyping();
        const intro = `Here are the top 3 ${intent.label}s I found for you:`;
        addTop3Cards(top3, intent.category, intro);
        addMsg(`Tap **Book Appointment** on any card to schedule. Need someone else?`, 'bot');
      }
      return;
    }
  }

  // General AI chat
  try {
    const system = `You are FindPro AI, a smart assistant for finding and booking professional talent. Available categories: designers, developers, photographers, architects, marketers, writers. Be friendly, concise (under 100 words). If user asks for a professional, they'll see live cards — just guide them. For booking questions, tell them to click the "Book Appointment" button on any professional card.`;

    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        system,
        messages: chatHistory.slice(-10)
      })
    });
    const data = await res.json();
    hideTyping();
    const reply = data.content?.map(b => b.text||'').join('') || "Sorry, I had trouble connecting. Try again!";
    addMsg(reply, 'bot');
    chatHistory.push({ role: 'assistant', content: reply });
  } catch(e) {
    hideTyping();
    addMsg("I'm having a connection issue. Please try again shortly.", 'bot');
  }
}

function quickChat(text) {
  document.getElementById('chat-inp').value = text;
  sendChat();
}
