// ===== PROFESSIONALS DATABASE =====
const PROFESSIONALS = [
  // DESIGNERS
  { id: 1, name: "Priya Sharma", role: "Senior UI/UX Designer", avatar: "PS", category: "designer", location: "Bangalore, India", rating: 4.9, reviews: 142, experience: "7 years", rate: 4500, rateUnit: "/hr", aiScore: 97, verified: true, topRated: true, skills: ["Figma","User Research","Prototyping","Design Systems","Wireframing"], desc: "Award-winning UI/UX designer specializing in SaaS products and mobile apps. Previously at Flipkart and Razorpay. Helped 80+ companies redesign their products.", availability: "Available in 2 days", platform: "Toptal" },
  { id: 2, name: "Alex Chen", role: "Product & Brand Designer", avatar: "AC", category: "designer", location: "Singapore", rating: 4.8, reviews: 98, experience: "5 years", rate: 3800, rateUnit: "/hr", aiScore: 92, verified: true, topRated: false, skills: ["Branding","Logo Design","Figma","Adobe XD","Motion Design"], desc: "Crafting memorable brand identities and product experiences for startups and enterprises. Strong portfolio across fintech, healthcare, and e-commerce sectors.", availability: "Available now", platform: "Dribbble" },
  { id: 3, name: "Ravi Menon", role: "Graphic & Visual Designer", avatar: "RM", category: "designer", location: "Mumbai, India", rating: 4.7, reviews: 215, experience: "6 years", rate: 2200, rateUnit: "/hr", aiScore: 88, verified: true, topRated: true, skills: ["Illustrator","Photoshop","Brand Identity","Print Design","Social Media"], desc: "Versatile visual designer with expertise in brand identity, print, and digital media. Worked with 150+ brands across India and Southeast Asia.", availability: "Available in 1 week", platform: "99designs" },
  { id: 4, name: "Sara Williams", role: "UX Researcher & Designer", avatar: "SW", category: "designer", location: "London, UK", rating: 4.8, reviews: 67, experience: "4 years", rate: 5200, rateUnit: "/hr", aiScore: 89, verified: true, topRated: false, skills: ["User Research","Usability Testing","Figma","Journey Mapping","A/B Testing"], desc: "Data-driven UX designer focused on research and usability. Certified in UX from Google. Strong background in enterprise SaaS and fintech products.", availability: "Available in 3 days", platform: "Upwork" },
  { id: 5, name: "Mohammed Al-Rashid", role: "Motion & UI Designer", avatar: "MA", category: "designer", location: "Dubai, UAE", rating: 4.6, reviews: 88, experience: "5 years", rate: 3500, rateUnit: "/hr", aiScore: 83, verified: false, topRated: false, skills: ["After Effects","Lottie","UI Design","Animation","Micro-interactions"], desc: "Specializing in motion design and animated UI components. Expert in creating delightful micro-interactions and onboarding animations for apps.", availability: "Available in 5 days", platform: "Behance" },

  // DEVELOPERS
  { id: 6, name: "Arjun Kapoor", role: "Full Stack Developer", avatar: "AK", category: "developer", location: "Hyderabad, India", rating: 5.0, reviews: 311, experience: "8 years", rate: 5500, rateUnit: "/hr", aiScore: 99, verified: true, topRated: true, skills: ["React","Node.js","AWS","PostgreSQL","TypeScript"], desc: "Top-rated full stack developer on multiple platforms. Built scalable systems serving millions of users. Expert in cloud architecture and microservices.", availability: "Available now", platform: "Toptal" },
  { id: 7, name: "Elena Petrov", role: "Python / ML Engineer", avatar: "EP", category: "developer", location: "Berlin, Germany", rating: 4.9, reviews: 174, experience: "6 years", rate: 6200, rateUnit: "/hr", aiScore: 95, verified: true, topRated: true, skills: ["Python","TensorFlow","FastAPI","Docker","Kubernetes"], desc: "Machine learning engineer with strong Python backend skills. Published researcher in NLP. Deployed production ML models for Fortune 500 companies.", availability: "Available in 4 days", platform: "Arc.dev" },
  { id: 8, name: "Karthik Nair", role: "React Native Developer", avatar: "KN", category: "developer", location: "Chennai, India", rating: 4.7, reviews: 129, experience: "5 years", rate: 3200, rateUnit: "/hr", aiScore: 86, verified: true, topRated: false, skills: ["React Native","iOS","Android","Firebase","Redux"], desc: "Specialist in cross-platform mobile apps. Published 20+ apps on App Store and Play Store with 4.5+ ratings. Expert in performance optimization.", availability: "Available now", platform: "Upwork" },
  { id: 9, name: "James O'Brien", role: "Backend / DevOps Engineer", avatar: "JO", category: "developer", location: "Dublin, Ireland", rating: 4.8, reviews: 92, experience: "7 years", rate: 5800, rateUnit: "/hr", aiScore: 91, verified: true, topRated: false, skills: ["Go","AWS","Terraform","CI/CD","Microservices"], desc: "Backend and DevOps specialist focusing on cloud-native architectures. Expert in building highly available distributed systems and automating infrastructure.", availability: "Available in 1 week", platform: "GitHub" },
  { id: 10, name: "Tanvi Desai", role: "Frontend Developer", avatar: "TD", category: "developer", location: "Pune, India", rating: 4.6, reviews: 156, experience: "4 years", rate: 2800, rateUnit: "/hr", aiScore: 82, verified: true, topRated: false, skills: ["Vue.js","React","CSS","Performance","Accessibility"], desc: "Frontend specialist obsessed with performance and accessibility. Core contributor to open-source UI libraries. Expert in building pixel-perfect interfaces.", availability: "Available in 2 days", platform: "Fiverr" },

  // PHOTOGRAPHERS
  { id: 11, name: "Ananya Reddy", role: "Wedding & Portrait Photographer", avatar: "AR", category: "photographer", location: "Hyderabad, India", rating: 4.9, reviews: 443, experience: "9 years", rate: 35000, rateUnit: "/day", aiScore: 96, verified: true, topRated: true, skills: ["Wedding","Portraits","Candid","Post-Processing","Videography"], desc: "Award-winning wedding photographer. Captured 600+ weddings across India. Featured in Vogue India and Harper's Bazaar. Natural, candid storytelling style.", availability: "Available in 2 weeks", platform: "Thumbtack" },
  { id: 12, name: "David Lim", role: "Commercial & Product Photographer", avatar: "DL", category: "photographer", location: "Bangalore, India", rating: 4.8, reviews: 287, experience: "7 years", rate: 18000, rateUnit: "/day", aiScore: 90, verified: true, topRated: false, skills: ["Product Photography","E-commerce","Food Photography","Lighting","Retouching"], desc: "Commercial photographer specializing in product and e-commerce photography. Clients include Amazon, Myntra, Swiggy. Studio and on-location shoots.", availability: "Available in 3 days", platform: "Snappr" },
  { id: 13, name: "Kavya Iyer", role: "Fashion & Event Photographer", avatar: "KI", category: "photographer", location: "Mumbai, India", rating: 4.7, reviews: 198, experience: "6 years", rate: 22000, rateUnit: "/day", aiScore: 85, verified: true, topRated: false, skills: ["Fashion","Events","Corporate","Editorial","Drone Photography"], desc: "Fashion and event photographer with editorial sensibility. Shot for top fashion brands and corporate events. FAA-licensed drone operator for aerial shots.", availability: "Available now", platform: "Pixieset" },

  // ARCHITECTS
  { id: 14, name: "Rahul Verma", role: "Residential Architect", avatar: "RV", category: "architect", location: "Delhi, India", rating: 4.8, reviews: 76, experience: "12 years", rate: 180000, rateUnit: "/project", aiScore: 93, verified: true, topRated: true, skills: ["Residential Design","3D Visualization","AutoCAD","Revit","Sustainable Design"], desc: "Award-winning residential architect known for seamlessly blending modern aesthetics with traditional Indian sensibilities. 200+ homes designed across North India.", availability: "Available in 1 week", platform: "Houzz" },
  { id: 15, name: "Meera Pillai", role: "Interior & Commercial Architect", avatar: "MP", category: "architect", location: "Kochi, India", rating: 4.9, reviews: 54, experience: "10 years", rate: 250000, rateUnit: "/project", aiScore: 94, verified: true, topRated: true, skills: ["Interior Architecture","Commercial","Retail Design","LEED Certified","BIM"], desc: "LEED-certified architect specializing in sustainable commercial and retail spaces. Named one of India's top 40 under 40 architects by Architectural Digest.", availability: "Available in 2 weeks", platform: "Architizer" },

  // DIGITAL MARKETERS
  { id: 16, name: "Sneha Goel", role: "Performance Marketing Specialist", avatar: "SG", category: "marketer", location: "Gurgaon, India", rating: 4.9, reviews: 201, experience: "6 years", rate: 3500, rateUnit: "/hr", aiScore: 95, verified: true, topRated: true, skills: ["Google Ads","Meta Ads","SEO","Analytics","CRO"], desc: "Managed ₹50Cr+ in ad spend across Google and Meta. Average ROAS of 6x for e-commerce clients. Certified Google Ads and Meta Blueprint expert.", availability: "Available now", platform: "Clutch" },
  { id: 17, name: "Nathan Brooks", role: "SEO & Content Strategist", avatar: "NB", category: "marketer", location: "Bangalore, India", rating: 4.7, reviews: 145, experience: "5 years", rate: 2800, rateUnit: "/hr", aiScore: 86, verified: true, topRated: false, skills: ["SEO","Content Strategy","Ahrefs","Link Building","Technical SEO"], desc: "Helped 80+ companies rank on Google's first page. Average 300% organic traffic increase within 6 months. Specialist in technical SEO and content-led growth.", availability: "Available in 3 days", platform: "Mayple" },

  // WRITERS
  { id: 18, name: "Divya Krishnan", role: "Tech Content Writer", avatar: "DK", category: "writer", location: "Chennai, India", rating: 4.8, reviews: 312, experience: "5 years", rate: 800, rateUnit: "/article", aiScore: 91, verified: true, topRated: true, skills: ["Technical Writing","SaaS","B2B Content","SEO Writing","Case Studies"], desc: "Top-rated tech content writer for SaaS, AI, and fintech companies. 500+ articles published. Clients include Zoho, Freshworks, and Y Combinator startups.", availability: "Available now", platform: "Contently" },
  { id: 19, name: "Oliver Hart", role: "Copywriter & Brand Storyteller", avatar: "OH", category: "writer", location: "Pune, India", rating: 4.7, reviews: 189, experience: "7 years", rate: 1200, rateUnit: "/article", aiScore: 87, verified: true, topRated: false, skills: ["Copywriting","Brand Voice","Email Marketing","Landing Pages","UX Writing"], desc: "Conversion-focused copywriter with deep expertise in brand voice and storytelling. Helped startups raise $50M+ with compelling pitch narratives.", availability: "Available in 2 days", platform: "Scripted" }
];

// ===== SEARCH & FILTER ENGINE =====
function searchProfessionals(query, filters = {}) {
  const q = query.toLowerCase().trim();
  let results = PROFESSIONALS.filter(p => {
    const matchQuery = !q ||
      p.name.toLowerCase().includes(q) ||
      p.role.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      p.skills.some(s => s.toLowerCase().includes(q)) ||
      p.desc.toLowerCase().includes(q) ||
      p.location.toLowerCase().includes(q);

    const matchCategory = !filters.category || filters.category === 'all' || p.category === filters.category;
    const matchRating = !filters.minRating || p.rating >= filters.minRating;
    const matchVerified = !filters.verifiedOnly || p.verified;
    const matchTopRated = !filters.topRatedOnly || p.topRated;

    return matchQuery && matchCategory && matchRating && matchVerified && matchTopRated;
  });

  // Sort
  if (filters.sort === 'rating') results.sort((a, b) => b.rating - a.rating);
  else if (filters.sort === 'price_asc') results.sort((a, b) => a.rate - b.rate);
  else if (filters.sort === 'price_desc') results.sort((a, b) => b.rate - a.rate);
  else if (filters.sort === 'reviews') results.sort((a, b) => b.reviews - a.reviews);
  else results.sort((a, b) => b.aiScore - a.aiScore); // default: AI score

  return results;
}

// ===== CATEGORY LABEL MAP =====
const CATEGORY_LABELS = { designer: 'Designer', developer: 'Developer', photographer: 'Photographer', architect: 'Architect', marketer: 'Marketer', writer: 'Writer' };

function getCategoryFromQuery(q) {
  q = q.toLowerCase();
  if (q.includes('design') || q.includes('ux') || q.includes('ui') || q.includes('graphic')) return 'designer';
  if (q.includes('develop') || q.includes('code') || q.includes('program') || q.includes('engineer') || q.includes('react') || q.includes('python')) return 'developer';
  if (q.includes('photo')) return 'photographer';
  if (q.includes('architect')) return 'architect';
  if (q.includes('market') || q.includes('seo') || q.includes('ads')) return 'marketer';
  if (q.includes('writ') || q.includes('content') || q.includes('copy')) return 'writer';
  return null;
}
