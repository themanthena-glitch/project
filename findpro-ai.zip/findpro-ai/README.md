# FindPro AI — Professional Search & Booking Platform

## What This Does
An AI-powered website to **find, compare, and book top professionals** (designers, developers, photographers, architects, marketers, writers).

---

## Features
- **AI-Powered Search** — Search across 19 professionals with smart keyword matching
- **AI Match Score** — Each professional gets an AI relevance score (%)
- **AI Suggestion Bar** — Claude AI writes a personalized recommendation for your search
- **Filters & Sort** — Filter by category, rating, verified, top-rated; sort by AI score, price, reviews
- **Book Appointment** — Pick a date, time slot, project type, and confirm a booking
- **My Bookings Page** — View, filter, and cancel your bookings (saved in browser)
- **AI Chatbot** — Floating assistant powered by Claude API on every page

---

## File Structure
```
findpro-ai/
├── index.html          ← Homepage with hero search + categories
├── css/
│   └── style.css       ← All styles (responsive)
├── js/
│   ├── data.js         ← Professionals database + search engine
│   ├── chat.js         ← AI chatbot (Claude API)
│   └── booking.js      ← Booking modal logic
└── pages/
    ├── search.html     ← Search results + filters + booking modal
    └── bookings.html   ← My Bookings management page
```

---

## How to Run
Just open `index.html` in any browser — no server needed.

> **Note:** The AI chatbot and AI suggestion bar call the Anthropic Claude API. These work automatically inside the Claude.ai artifact environment. If running locally, you'd need to add your API key.

---

## How to Use
1. **Search** — Type any profession on the homepage or search page
2. **Filter** — Use the sidebar to narrow by category, rating, verified status
3. **Compare** — See AI match scores and ratings side-by-side
4. **Book** — Click "Book Appointment" → pick date & time → confirm
5. **Manage** — Go to "My Bookings" to view or cancel appointments
6. **Ask AI** — Use the floating chatbot for help finding the right professional

---

## To Add More Professionals
Edit `js/data.js` and add a new object to the `PROFESSIONALS` array following the same format.
